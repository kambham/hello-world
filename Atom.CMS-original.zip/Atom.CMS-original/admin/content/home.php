<?php ## Home Page Content ?>

<h2>ATOM.CMS</h2>
<h3>Administration Panel Home</h3>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin imperdiet tincidunt est vel ultricies. Quisque id ipsum eget metus pharetra ultricies et quis dolor. Quisque mollis pellentesque eros at condimentum. Proin turpis libero, tincidunt sit amet fringilla id, molestie id mi. Proin in nisl sed ipsum ultricies pharetra. Aliquam eu ligula in metus viverra lobortis eu sagittis mi. Morbi sed fringilla ligula. Donec nunc ante, sagittis vel accumsan vel, sagittis quis dui. Sed luctus nunc ut leo molestie elementum. Duis non sem id augue egestas egestas sit amet sit amet diam. Proin mi arcu, pellentesque et tincidunt a, cursus a libero. Vestibulum dolor metus, fringilla in sodales a, malesuada in justo. Ut quis nisl lectus. Vestibulum ut dolor diam, nec tincidunt tortor. Vestibulum cursus gravida blandit.</p>

