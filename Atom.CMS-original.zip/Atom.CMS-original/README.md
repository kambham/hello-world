AtomCMS - Original
=========================

Preface
-------------------------

This branch is the original version of the AtomCMS from the first video series "Building a Dynamic Website from Start to Finish".  

A completely new version will be started in 2014 along with a new video series.

This repository DOES NOT include the Redactor WYSIWYG plugin.  We do not own the plugin and it is used in our CMS for example purposes.

To download a copy of Redactor please visit their website
[download Redactor] (http://imperavi.com/redactor/)

Thanks!
Alan
The Digital Craft
